/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [".*.html"],
  theme: {
    extend: {
      colors:{
        'violet':'#634EE2'
      }
    },
  },
  plugins: [
  ],
}

